package com.balancetracking.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Shader
import android.graphics.Typeface
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.view.View
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Full-screen water. The glass is always half full. The water surface stays
 * perpendicular to gravity, so a phone tilted 45 degrees shows a surface
 * tilted 45 degrees. A spring makes the water lag behind and slosh, and
 * moving the phone fast makes bigger waves.
 */
class WaterView(context: Context) : View(context), SensorEventListener {

    private val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    private val accelerometer: Sensor? = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)

    private val density = resources.displayMetrics.density
    private val fillFraction = 0.5f

    // Smoothed sensor reading.
    private var fax = 0f
    private var fay = 9.81f

    // Target "down" direction in screen coordinates (x right, y down).
    private var tx = 0f
    private var ty = 1f

    // Displayed "down" direction and its velocity (spring simulation).
    private var cx = 0f
    private var cy = 1f
    private var vx = 0f
    private var vy = 0f

    private var slosh = 0f
    private var phase = 0f
    private var lastNs = 0L

    private var angleDeg = 0f
    private var balancedSeconds = 0f
    private var running = false

    private val skyPaint = Paint()
    private val backPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val waterPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val linePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2f * density
        color = Color.argb(150, 255, 255, 255)
        strokeJoin = Paint.Join.ROUND
    }
    private val bigText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textAlign = Paint.Align.CENTER
        textSize = 72f * density
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    }
    private val smallText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(220, 255, 255, 255)
        textAlign = Paint.Align.CENTER
        textSize = 16f * density
    }

    private val wave = Path()
    private val surface = Path()

    fun start() {
        if (running) return
        running = true
        lastNs = 0L
        accelerometer?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
        invalidate()
    }

    fun stop() {
        running = false
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent) {
        val ax = event.values[0]
        val ay = event.values[1]
        fax += (ax - fax) * 0.25f
        fay += (ay - fay) * 0.25f
        // Phone lying flat: no usable direction, keep the last one.
        if (hypot(fax, fay) < 1.5f) return
        // Sensor y points up the screen; screen y points down. Gravity in
        // screen coordinates is (-ax, ay).
        val gx = -fax
        val gy = fay
        val len = hypot(gx, gy)
        tx = gx / len
        ty = gy / len
        angleDeg = Math.toDegrees(atan2(tx.toDouble(), ty.toDouble())).toFloat()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) = Unit

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        if (w == 0f || h == 0f) return

        val now = System.nanoTime()
        val dt = if (lastNs == 0L) 0.016f else min(0.05f, (now - lastNs) / 1e9f)
        lastNs = now
        step(dt)

        // Empty glass background.
        skyPaint.shader = LinearGradient(
            0f, 0f, 0f, h,
            Color.parseColor("#0B1B2B"), Color.parseColor("#10283F"), Shader.TileMode.CLAMP
        )
        canvas.drawRect(0f, 0f, w, h, skyPaint)

        // Unit vector pointing to where the water is.
        val len = hypot(cx, cy).coerceAtLeast(0.0001f)
        val nx = cx / len
        val ny = cy / len

        val t = findOffset(w, h, nx, ny)
        val centerX = w / 2f
        val centerY = h / 2f
        val baseX = centerX + nx * t
        val baseY = centerY + ny * t
        val reach = hypot(w, h)

        val amp = 3f * density + slosh * 26f * density

        // Back wave layer, lighter and slower.
        buildWave(wave, baseX, baseY, nx, ny, reach, amp * 0.8f, phase * 0.7f + 1.7f, closeFar = true)
        backPaint.shader = LinearGradient(
            baseX, baseY, baseX + nx * h * 0.6f, baseY + ny * h * 0.6f,
            Color.argb(120, 90, 190, 245), Color.argb(120, 20, 90, 170), Shader.TileMode.CLAMP
        )
        canvas.drawPath(wave, backPaint)

        // Front wave layer.
        buildWave(wave, baseX, baseY, nx, ny, reach, amp, phase, closeFar = true)
        waterPaint.shader = LinearGradient(
            baseX, baseY, baseX + nx * h * 0.6f, baseY + ny * h * 0.6f,
            Color.argb(235, 40, 150, 225), Color.argb(245, 6, 60, 130), Shader.TileMode.CLAMP
        )
        canvas.drawPath(wave, waterPaint)

        // Bright edge on the surface.
        buildWave(surface, baseX, baseY, nx, ny, reach, amp, phase, closeFar = false)
        canvas.drawPath(surface, linePaint)

        drawReadout(canvas, w, h, dt)

        if (running) postInvalidateOnAnimation()
    }

    /** Spring toward the real gravity direction. Low damping gives slosh. */
    private fun step(dt: Float) {
        val k = 70f
        val c = 4.5f
        var remaining = dt
        val sub = 0.004f
        var speed = 0f
        while (remaining > 0f) {
            val d = min(sub, remaining)
            val axl = k * (tx - cx) - c * vx
            val ayl = k * (ty - cy) - c * vy
            vx += axl * d
            vy += ayl * d
            cx += vx * d
            cy += vy * d
            speed = hypot(vx, vy)
            remaining -= d
        }
        val l = hypot(cx, cy)
        if (l > 0.0001f) {
            cx /= l
            cy /= l
        }
        val target = min(1f, speed * 0.9f)
        slosh += (target - slosh) * min(1f, dt * 6f)
        phase += dt * (2.2f + slosh * 4f)
    }

    private fun buildWave(
        path: Path, baseX: Float, baseY: Float, nx: Float, ny: Float,
        reach: Float, amp: Float, ph: Float, closeFar: Boolean
    ) {
        path.reset()
        val tanX = -ny
        val tanY = nx
        val stepPx = 8f * density
        var s = -reach
        var first = true
        while (s <= reach) {
            val off = amp * (0.6f * sin(s * 0.016f / density * 2f + ph) +
                    0.4f * sin(s * 0.031f / density * 2f - ph * 1.3f))
            val px = baseX + tanX * s - nx * off
            val py = baseY + tanY * s - ny * off
            if (first) {
                path.moveTo(px, py)
                first = false
            } else {
                path.lineTo(px, py)
            }
            s += stepPx
        }
        if (closeFar) {
            path.lineTo(baseX + tanX * reach + nx * reach * 2f, baseY + tanY * reach + ny * reach * 2f)
            path.lineTo(baseX - tanX * reach + nx * reach * 2f, baseY - tanY * reach + ny * reach * 2f)
            path.close()
        }
    }

    /**
     * Finds the offset t (along the water direction, from the screen centre)
     * where the surface line must sit so the water covers exactly
     * [fillFraction] of the screen, whatever the tilt.
     */
    private fun findOffset(w: Float, h: Float, nx: Float, ny: Float): Float {
        val hw = w / 2f
        val hh = h / 2f
        val r = hypot(hw, hh)
        var lo = -r
        var hi = r
        val target = fillFraction * w * h
        repeat(28) {
            val mid = (lo + hi) / 2f
            if (areaBeyond(hw, hh, nx, ny, mid) > target) lo = mid else hi = mid
        }
        return (lo + hi) / 2f
    }

    /** Area of the screen rectangle where dot(p, n) >= t, p relative to centre. */
    private fun areaBeyond(hw: Float, hh: Float, nx: Float, ny: Float, t: Float): Float {
        val xs = floatArrayOf(-hw, hw, hw, -hw)
        val ys = floatArrayOf(-hh, -hh, hh, hh)
        val outX = ArrayList<Float>(6)
        val outY = ArrayList<Float>(6)
        for (i in 0 until 4) {
            val j = (i + 1) % 4
            val di = xs[i] * nx + ys[i] * ny - t
            val dj = xs[j] * nx + ys[j] * ny - t
            if (di >= 0f) {
                outX.add(xs[i]); outY.add(ys[i])
            }
            if ((di >= 0f) != (dj >= 0f)) {
                val f = di / (di - dj)
                outX.add(xs[i] + (xs[j] - xs[i]) * f)
                outY.add(ys[i] + (ys[j] - ys[i]) * f)
            }
        }
        if (outX.size < 3) return 0f
        var a = 0f
        for (i in outX.indices) {
            val j = (i + 1) % outX.size
            a += outX[i] * outY[j] - outX[j] * outY[i]
        }
        return abs(a) / 2f
    }

    private fun drawReadout(canvas: Canvas, w: Float, h: Float, dt: Float) {
        val level = abs(angleDeg) < 2f
        if (level) balancedSeconds += dt else balancedSeconds = 0f

        val shown = Math.round(angleDeg)
        val label = if (shown > 0) "$shown°" else if (shown < 0) "$shown°" else "0°"
        val topInset = 72f * density
        canvas.drawText(label, w / 2f, topInset + bigText.textSize * 0.4f, bigText)

        val status = if (level) {
            "Level  •  %.1f s balanced".format(balancedSeconds)
        } else {
            "Tilt angle"
        }
        canvas.drawText(status, w / 2f, topInset + bigText.textSize * 0.4f + 30f * density, smallText)
    }
}
